const Customer = require('../model/customer');
const stripe = require('stripe')('sk_test_51N1uLfSFOmUeWPsILfUA6c2TQO7z9nlkNJruEWPfMc6oi0cWEMgLBmuJUFgsmWWedplywQgnJJFxw4JbFW8woldr00iOJMo05g');

exports.stripePayment = async (req, res, next) => {
    var customerName = req.body.customers;
    Customer.findOne({ customerName: customerName })
        .then(result => {
            res.render('payment', {
                key: 'pk_test_51N1uLfSFOmUeWPsID6IVuh4BU4UzaUB9ah0FqMLwjyRi4KIBYyges7LlMoWUA6jlUXh579M61esabkCtgDCp1r5B004snmyMz4',
                customerName: customerName,
                amountCharged: result.amountCharged
            })
        })
}

exports.paymentCompleted = async (req, res, next) => {

    // var customerName = req.body.customer;
    var amountCharged = req.body.amount;

    stripe.paymentIntents.create({
        amount: amountCharged * 100,
        currency: 'inr',
        payment_method_types: ['card'],
        customer: 'cus_NnW0PKtQ5Otd92',
    }, { stripeAccount: 'acct_1MlQ9rSBkF0GV1OM' })
        .then(paymentIntent => {
            stripe.paymentIntents.confirm(paymentIntent.id, { payment_method: 'pm_card_visa' }).then(result => {

                console.log(result)
            }).catch(err => console.log(err))
        }).then(result => {

            console.log(result)
        }).catch(err => console.log(err))

    res.redirect('getData');
}